import React from 'react';
import { Text, View,Image,TextInput,TouchableOpacity,StyleSheet, KeyboardAvoidingView } from 'react-native';
import { Header } from 'react-native-elements';
import db from '../config'



export default class ScanScreen extends React.Component{
    constructor(){
        super();
        this.state={
            storytext: '',
            aurthortext:'',
            text:''
        }
    }
    submitStory=()=>{
    var r= db.ref('StoryDetails/'+'/');
    r.update({
      Title:this.state.text,
      Aurthor:this.state.aurthortext,
      Story:this.state.storytext
    })
    }

    render(){
    return(
      <KeyboardAvoidingView>
        <View>
        <Header
          backgroundColor={'lightblue'}
          centerComponent={{
            text: 'Story Hub',
            style: { color: 'white',fontWeight: 'bold', fontSize: 30 },
          }}
        />
        <Text style={{fontSize:18,marginTop:10}}>Title of the story:</Text>
        <TextInput
          style={styles.inputBox}
          onChangeText={text => {
            this.setState({ text: text });
          }}
          value={this.state.text}
        />
        <Text style={{fontSize:18,marginTop:5}}>Name of the Aurtor:</Text>
                <TextInput style={styles.inputBox}
          onChangeText={aurthortext => {
            this.setState({ aurthortext: aurthortext });
          }}
          value={this.state.aurthortext}
        />
        <Text style={{fontSize:18,marginTop:5}}>Story:</Text>
          <TextInput
          style={styles.inputBox2}
          onChangeText={storytext => {
            this.setState({ storytext: storytext });
          }}
          value={this.state.storytext}
        />
 
        <TouchableOpacity style={styles.buttons} onPress={this.submitStory}><Text style={{fontSize:18}}>Submit</Text></TouchableOpacity>

        </View>
        </KeyboardAvoidingView>   
    )   
}
}

const styles = StyleSheet.create({
  inputBox: {
    marginTop: 10,
    width: '80%',
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    borderWidth: 4,
    outline: 'none',
  },
  inputBox2: {
    marginTop: 10,
    width: 300,
    alignSelf: 'center',
    height:300,
    textAlign: 'center',
    borderWidth: 4,
    //outline: 'none',
  },
    buttons: {
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf:'center',
    borderWidth: 2,
    borderRadius: 15,
    margin: 10,
    width: 200,
    height: 50,
    backgroundColor:'lightblue'
  }
});