import React from 'react';
import { Text, View,Image,TextInput,TouchableOpacity,FlatList } from 'react-native';
import { Header } from 'react-native-elements';
import {SearchBar} from 'react-native-elements';
import db from '../config'

export default class ReadStoryScreen extends React.Component{
    render(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
        <Header
          backgroundColor={'lightblue'}
          centerComponent={{
            text: 'Story Hub',
            style: { color: 'white',fontWeight: 'bold', fontSize: 30, width: 300,
    height:40 },
          }}
        />

            <Text style={{fontSize:18}}>Read a story</Text>

        </View>
    )
        
}
}