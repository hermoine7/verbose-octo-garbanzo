import firebase from 'firebase';

var firebaseConfig = {
    apiKey: "AIzaSyCKvWm8EjBGm28bg_w4U6ZqOaQtMX--sz4",
    authDomain: "stort-hub.firebaseapp.com",
    databaseURL: "https://stort-hub.firebaseio.com",
    projectId: "stort-hub",
    storageBucket: "stort-hub.appspot.com",
    messagingSenderId: "447525105082",
    appId: "1:447525105082:web:bd8eaa5e3e751c91558183"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  export default firebase.database();